<?php
print_r($category);