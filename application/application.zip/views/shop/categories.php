<?php
print_r($categories);